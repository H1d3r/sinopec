// JavaScript Document
Ext.onReady(function() {
    var items = [];
    var tree = Ext.create('Ext.tree.Panel', {
        title: '',
        root: {			
            	text: ' 大标题 ',
            	expanded: true,
            	children: [{
					text: ' 二标题1',
					expanded: true,
                	children: [{
                    	text: ' 三标题',
                		children: [{
                    		text: ' 文件',
                    		leaf: true
                			}]
			 			}]
					},{
						text: ' 二标题2',
						expanded: true,
                		children: [{
                    		text: ' 三标题',
                			children: [{
                    			text: ' 文件',
                    			leaf: true
                				}]
			 				}]
						}]
        		}
				
		/*
        root: {
            text: '标题',
            expanded: true,
            children: [{
                text: '内容 1',
                leaf: true
            }, {
                text: '内容 2',
                leaf: true
            }, {
				text: '2 号标题',
                children: [{
                    text: '内容',
                    leaf: true
                }]
            },{
				text: '2 号标题',
				expanded: true,
                children: [{
                    text: '3 号标题',
                	children: [{
                    text: '内容 3',
                    leaf: true
                }]
			 }]
			}]
        }*/
    });
    var accConfig = {
        layout: 'accordion',
        x: 190, y: 160,

        width : 450,
        height: 300,

        bodyStyle: {
            'margin-left': '50px'
        },

        items: [
            tree, {
                title: '',
                html: ''
            }, {
                title: '',
                html : ''
            }
        ]
    };
    items.push(accConfig);
    //=============================================================
    for (var i = 0; i < items.length; i++) {
      items[i].style = {
            position: 'absolute'
        };
        var item = Ext.ComponentManager.create(items[i], 'panel');
        item.render(document.body);
    }
});

