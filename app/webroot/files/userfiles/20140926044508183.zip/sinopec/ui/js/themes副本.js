// JavaScript Document
Ext.onReady(function() {
    var items = [];
    var tree = Ext.create('Ext.tree.Panel', {
        title: '',
        root: {			
            	text: ' One ',
            	expanded: true,
            	children: [{
					text: ' Two',
					expanded: true,
                	children: [{
                    	text: ' Three',
                		children: [{
                    		text: ' Four',
                    		leaf: true
                			}]
			 			}]
					}]
        		}	
				
		/*
        root: {
            text: '����',
            expanded: true,
            children: [{
                text: '���� 1',
                leaf: true
            }, {
                text: '���� 2',
                leaf: true
            }, {
				text: '2 �ű���',
                children: [{
                    text: '����',
                    leaf: true
                }]
            },{
				text: '2 �ű���',
				expanded: true,
                children: [{
                    text: '3 �ű���',
                	children: [{
                    text: '���� 3',
                    leaf: true
                }]
			 }]
			}]
        }*/
    });
    var accConfig = {
        layout: 'accordion',
        x: 190, y: 470,

        width : 450,
        height: 300,

        bodyStyle: {
            'margin-left': '50px'
        },

        items: [
            tree, {
                title: '',
                html: ''
            }, {
                title: '',
                html : ''
            }
        ]
    };
    items.push(accConfig);
    //=============================================================
    for (var i = 0; i < items.length; i++) {
      items[i].style = {
            position: 'absolute'
        };
        var item = Ext.ComponentManager.create(items[i], 'panel');
        item.render(document.body);
    }
});

