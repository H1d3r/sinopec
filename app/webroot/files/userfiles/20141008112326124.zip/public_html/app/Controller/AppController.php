<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {
   
  /*
   * 因为我们希望我们整个网站的控制，身份验证和访问控制列表，我们将它们设置在 AppController的
   *
   * 创建 ‘root’ 或者被称为 ‘controllers’ 的顶层的 ACO。 
   * 这个root节点的目的是为了在整个应用的空间内更方便地允许/拒绝访问。 
   * 并且允许对 跨控制器/动作（例如检查模型记录权限）使用Acl。 
   * 为了使用全局的root ACO，我们需要修改 AuthComponent 配置。 
   * AuthComponent 需要知道root节点是否存在，所以当进行ACL 检查的时候它可以在控制器/动作中寻找到正确的节点路径。
   * 在中确保 AppController 你的 $components 数组中包含 actionPath 的定义 
   * 
   * 让我们增强应用的安全性，避免用户编辑或删除其他用户的posts，
   * 基本的规则是管理用户可以访问任何的url地址，
   * 当前的用户（作者角色）只可以访问到允许的地址。
   */
       public $components = array(
                    'DebugKit.Toolbar',
                    'Acl',
                    'Auth' => array(
//                        'loginRedirect' => array('controller' => 'posts', 'action' => 'index'),
                            'authorize' => array('Actions' => array('actionPath' => 'controllers') ,'Controller' ),//root 让我们增强应用的安全性，避免用户编辑或删除其他用户的posts，
                            'loginRedirect' => array('controller' => 'posts', 'action' => 'index'),
                            'logoutRedirect' => array('controller' => 'pages', 'action' => 'display', 'home')   
                    ),
           
                    'Session'
          );
       
       
            
            
            public $helpers = array('Html', 'Form', 'Session');

/*
 * 我们在 `` beforeFilter`` 中所做的功能是告诉组件 AuthComponent，在控制器中的所有 index 和 view 行动都不需要登录。
 * 我们希望我们的访问者能够读取和列出posts，而不需要注册网站。
 * 
 */            
                    public function beforeFilter() {
                        //Configure AuthComponent
                        $this->Auth->loginAction = array(
                          'controller' => 'users',
                          'action' => 'login'
                        );
                        $this->Auth->logoutRedirect = array(
                          'controller' => 'users',
                          'action' => 'login'
                        );
                        $this->Auth->loginRedirect = array(
                          'controller' => 'posts',
                          'action' => 'add'
                        );
                        $this->Auth->allow('display','index', 'view');
                    }
            

            
            /*
             * 
             * 我们只创建了一个非常简单的权限机制。
             * 在这个例子中用户登录后角色是``admin`` 的将可以访问任何地址，而其余的（例如角色 author ) 同未登录的用户一样不能够做任何事。
             * 这并不是我们所想要的，所以我们需要在我们的 isAuthorized() 方法中支持更多的规则. 与其在 AppController中设置, 
             * 不如委托每个控制器提供这些额外的规则。
             * 
             */
            
                public function isAuthorized($user) {
                        // Any registered user can access public functions
//                        if (empty($this->request->params['admin'])) {
//                            return true;
//                        }

                        // Only admins can access admin functions
//                        if (isset($this->request->params['admin'])) {
//                            return (bool)($user['group_id'] === '1');
//                        }
//                        // Default deny
//                        return false;
    
                }

    
    
}
