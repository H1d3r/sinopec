<?php
    phpinfo();
    
?>    